var app = angular.module('myApp', []);


// app.config(function($stateProvider, $urlRouterProvider){
//      $stateProvider
//      .state('ShowData',{
//         url:'/ShowData',
//         templateUrl: 'show.html'
//     })
//    .state('editData',{
//         url:'/editData',
//         templateUrl: 'edit.html'
//    })

//  });
//  app.controller('myctrl', function($location){

//     window.location = "show.html"
//  })
app.factory("myfactory", function(){
    var savedData = {};
    function set(data){
        savedData = data;
    }

    function get(){
        return savedData;
    }

    return{
        set:set,
        get:get
    }
});
app.controller('paymentscontroller', function($scope, $location, myfactory) { 
        $scope.prodctdetails = [
    
            {
                name: "Star TMT steel",
				tPrice:"5000",
				Icode:"9909",
                lastTransctiondate : "07 Oct 2017",
                remarks : "july",
                amount : "2000",
				accountfrom: ["telco", "telcoo", "Linus"]
            }
        ]
    
        $scope.submit = function(d){
            myfactory.set(d)
            window.location = "page2.html"
           //$location.path('/editData')
        }
});




app.controller("subcontroller",function($scope,$location,myfactory){
    $scope.Details = myfactory.get();

});